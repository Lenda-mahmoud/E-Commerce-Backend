const CategoryModel = require('../models/categoryModel');
exports. getCategories=(req, res) => {
    const name = req.body.name;
    console.log(req.body);

    const newcategory = new CategoryModel({name});
    newcategory.save().then((category) => {
        res.json(category);
    }).catch((err) => {
        console.error(err);
        res.status(500).send('An error occured');
    });
};
